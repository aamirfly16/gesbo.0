// alert Box

modernAlert();
            function modernAlertCallback(input) {
                if (typeof input === 'boolean') {
                    if (input === true) {
                        alert('You clicked ok!');
                    } else {
                        alert('You clicked cancel!');
                    }
                } else {
                    alert('Your name is ' + input + '!');
                }
            }
//modal box script
// Get the modal
		
			
			